
/**
 * Write a description of class CreateFirstObjects here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CreateFirstObjects
{
    // instance variables - replace the example below with your own
    private NaughtyDesign naughty;
    private MusicDesign music;
    private BuisnessDesign buisness;
    private TechDesign tech;
    private NatureDesign nature;

    /**
     * Constructor for objects of class CreateFirstObjects
     */
    public CreateFirstObjects()
    {
        // initialise instance variables
        naughty = new NaughtyDesign();
        music = new MusicDesign();
        buisness = new BuisnessDesign();
        tech = new TechDesign();
        nature = new NatureDesign();
    }

    
}
