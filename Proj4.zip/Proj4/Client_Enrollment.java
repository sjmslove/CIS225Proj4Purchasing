import java.util.ArrayList;
import java.util.Iterator;

/**
 * Write a description of class Client_Enrollment here.
 *displays client and purchase information
 * @author (your name)
 * @version (a version number or a date)
 */
public class Client_Enrollment
{
    // instance variables - replace the example below with your own
    private ArrayList<Client_Information> clients;

    /**
     * Constructor for objects of class Client_Enrollment
     */
    public Client_Enrollment()
    {
        // initialise instance variables
        this.clients = new ArrayList<>();
    }

    /**
     * Add client to System
     */
    public void enrollClient(Client_Information newClient)
    {
        clients.add(newClient);
    }
    
     /**
     * View Current Clients
     */
    public void viewClients ()
    {
        for( Client_Information  clients : clients) {
            System.out.println(clients.getDetails());
        }
    }
}
