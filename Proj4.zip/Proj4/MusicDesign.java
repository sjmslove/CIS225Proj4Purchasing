
/**
 * 
 * @Velma
 * 
 */
public class MusicDesign
{
    // instance variables - replace the example below with your own
    
    private static int BaseLine;
    private static int Feature1;
    private static int Feature2;
    private static int Feature3;
    private static int Feature4;
    private static int Feature5;

    /**
     * Constructor for objects of class MusicDesign
     */
    public MusicDesign()
    {
        BaseLine = 400;
        Feature1 = 85;
        Feature2 = 95;
        Feature3 = 110;
        Feature4 = 130;
        Feature5 = 210;
    }

    /**
     * Get Details
     */
    public static String getDetails()
    {
       return "Music Design Features include a base price of "
            + BaseLine + " The optional Features of Feature 1 $" + Feature1 +
            " Feature 2 $" + Feature2 + " Feature 3 $" + Feature3 +
            " Feature 4 $" + Feature4 + " Feature 5 $" + Feature5;
    }
    
    /** 
     * Get individual prices
     */
    public static int getBaseLine ()
    {
     return BaseLine;  
    }
    
    /** 
     * Get individual prices
     */
    public static int getFeature1 ()
    {
     return Feature1;  
    }
    
    /** 
     * Get individual prices
     */
    public static int getFeature2 ()
    {
     return Feature2;  
    }
    
    /** 
     * Get individual prices
     */
    public static int getFeature3 ()
    {
     return Feature3;  
    }
    
    /** 
     * Get individual prices
     */
    public static int getFeature4 ()
    {
     return Feature4;  
    }
    
    /** 
     * Get individual prices
     */
    public static int getFeature5 ()
    {
     return Feature5;  
    }
}
