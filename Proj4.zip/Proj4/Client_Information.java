import java.rmi.server.UID;
import java.util.ArrayList;
/**
 * Write a description of class Client_Information here.
 *basic client information
 * @author (your name)
 * @version (a version number or a date)
 */
public class Client_Information
{
    // instance variables - replace the example below with your own
    private String LastName;
    private String FirstName;
    private String Company;
    private String Address;
    private String City;
    private String State;
    private int Zip;
    private int PhoneNumber;
    private String CustId = "";
    private ArrayList<Purchase> purchase;
    private CreateFirstObjects start;
    private int Cost;
    private String Package;

    /**
     * Constructor for objects of class Client_Information
     */
    public Client_Information(String LastName, String FirstName, String Company, String Address, String City, String State, int Zip, int PhoneNumber)
    {
        this.LastName = LastName;
        this.FirstName = FirstName;
        this.Company = Company;
        this.Address =  Address;
        this.City = City;
        this.State = State;
        this.Zip = Zip;
        this.PhoneNumber = PhoneNumber;
        while (CustId == null) 
        {
            UID CustId = new UID();
        }
        this.purchase = new ArrayList<>();
        start = new CreateFirstObjects();
    }

    /**
     * show client name
     */
    public String getClient()
    {
        return LastName +", " + FirstName;
    }
    /**
     * show client details
     * 
     * come back later to set up on new line
     */
    public String getDetails()
    {
        return LastName + ", "+ FirstName +
            " ,Address: " + Address +
            ",City: " + City +
            "State: " + State +
            "Zip: " + Zip +
            "Phone Number: " + PhoneNumber +
            "Purchase: " + Cost +
            "Package: " + Package;
    }
    
    public void getTotal(Purchase purchase)
    {
        Cost = purchase.seeTotal();
        Package = purchase.getDetails();
    }
    
    
    public void getPurchase(Purchase newPurchase)
    {
      purchase.add(newPurchase);   
    }
   
}
    
    
