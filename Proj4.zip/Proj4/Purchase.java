
/**
 * Write a description of class Purchase here.
 *allows client to make a purchase
 * @author (your name)
 * @version (a version number or a date)
 */
public class Purchase
{
    private String Design;
    
    private int Baseline;
    private int TotalCost;
    private int Feature1;
    private int Feature2;
    private int Feature3;
    private int Feature4;
    private int Feature5;
    private int option1;
    private int option2;
    private int option3;
    private int option4;
    private int option5;
    private String Included1;
    private String Included2;
    private String Included3;
    private String Included4;
    private String Included5;

    /**
     * Constructor for objects of class Purchase
     */
    public Purchase()
    {        
        System.out.println("Please select from the following web designs:");
        System.out.println( NatureDesign.getDetails());
        System.out.println( TechDesign.getDetails());
        System.out.println( BuisnessDesign.getDetails());
        System.out.println( MusicDesign.getDetails());
        System.out.println( NaughtyDesign.getDetails());
    }

    /**
     * have client select from web designs
     */
    public void selectDesign (String design)
    {
        if (design == "nature"){
                Design = "Nature";
                Baseline = NatureDesign.getBaseLine();
                Feature1 = NatureDesign.getFeature1();
                Feature2 = NatureDesign.getFeature2();
                Feature3 = NatureDesign.getFeature3();
                Feature4 = NatureDesign.getFeature4();
                Feature5 = NatureDesign.getFeature5();
                System.out.println(NatureDesign.getDetails());
        } else if (design == "tech") {
                Design = "Tech";
                Baseline = TechDesign.getBaseLine();
                Feature1 = TechDesign.getFeature1();
                Feature2 = TechDesign.getFeature2();
                Feature3 = TechDesign.getFeature3();
                Feature4 = TechDesign.getFeature4();
                Feature5 = TechDesign.getFeature5();
                System.out.println(TechDesign.getDetails());
        } else if (design == "buisness") {
                Design = "Buisness";
                Baseline = BuisnessDesign.getBaseLine();
                Feature1 = BuisnessDesign.getFeature1();
                Feature2 = BuisnessDesign.getFeature2();
                Feature3 = BuisnessDesign.getFeature3();
                Feature4 = BuisnessDesign.getFeature4();
                Feature5 = BuisnessDesign.getFeature5();
                System.out.println(BuisnessDesign.getDetails());
        } else if (design == "music"){
                Design = "Music";
                Baseline = MusicDesign.getBaseLine();
                Feature1 = MusicDesign.getFeature1();
                Feature2 = MusicDesign.getFeature2();
                Feature3 = MusicDesign.getFeature3();
                Feature4 = MusicDesign.getFeature4();
                Feature5 = MusicDesign.getFeature5();
                System.out.println(MusicDesign.getDetails());
        } else if (design == "naughty"){
                Design = "Naughty";
                Baseline = NaughtyDesign.getBaseLine();
                Feature1 = NaughtyDesign.getFeature1();
                Feature2 = NaughtyDesign.getFeature2();
                Feature3 = NaughtyDesign.getFeature3();
                Feature4 = NaughtyDesign.getFeature4();
                Feature5 = NaughtyDesign.getFeature5();
                System.out.println(NaughtyDesign.getDetails());
        } else {
            System.out.println("Not an option please select again");
        }
            
    }
    
    /**
     * select individual features
     */
    
    public void selectFeatures (String Feat1, String Feat2, String Feat3, String Feat4, String Feat5)
    {
        if (Feat1 == "yes") {
                option1 = Feature1;
                Included1 = "Feature 1 Purchased";
        } else{
                option1 = 0;
                Included1 = "not selected";
        }
        
        if (Feat2 == "yes") {
                option2 = Feature2;
                Included2 = "Feature 2 Purchased";
        } else{
                option2 = 0;
                Included2 = "not selected";
        }
        
        if (Feat3 == "yes") {
                option3 = Feature3;
                Included3 = "Feature 3 Purchased";
        } else{
                option3 = 0;
                Included3 = "not selected";
        }
        
        if (Feat4 == "yes") {
                option4 = Feature4;
                Included4 = "Feature 4 Purchased";
        } else{
                option4 = 0;
                Included4 = "not selected";
        }
        
        if (Feat5 == "yes") {
                option5 = Feature5;
                Included5 = "Feature 5 Purchased";
        } else{
                option5 = 0;
                Included5 = "not selected";
        }
    }
    
    public void getTotal()
    {
        TotalCost = Baseline + option1 + option2 + option3 + option4 + option5;
    }
    
      
    public int seeTotal()
    {
        return TotalCost;
    }
    
    public String getDetails()
    {
        return "Design Selected: " + Design + " " + Included1 + " " + Included2 + " " + Included3 + " " + Included4 + " " + Included5;
    }
}
